export default function HomePage(){
  return (
    <section className="py-12">
      <h1 className="text-4xl font-extrabold mb-4">NERIN · Ingeniería Eléctrica</h1>
      <p className="max-w-2xl">Sitio base funcionando. Ajustá contenido desde /admin (login sencillo) y probá las rutas /blog, /contacto y /calculadora.</p>
    </section>
  )
}
