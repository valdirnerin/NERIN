import fs from 'fs'
import path from 'path'
import mime from 'mime-types'
import { getStorageDir } from '@/lib/content'
export async function GET(_: Request, { params }: { params: { path: string[] } }){
  const storage = getStorageDir()
  const filePath = path.join(storage, 'media', ...params.path)
  if (!fs.existsSync(filePath)) return new Response('Not found', { status: 404 })
  const mimeType = mime.lookup(filePath) || 'application/octet-stream'
  const buf = fs.readFileSync(filePath)
  return new Response(buf, { headers: { 'Content-Type': String(mimeType) } })
}
