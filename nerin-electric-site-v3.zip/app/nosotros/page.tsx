import { readSite, readMarkdown } from '@/lib/content'
import { marked } from 'marked'
export const metadata = { title: 'Nosotros | NERIN' }
export default function Nosotros(){
  const site = readSite()
  const page = readMarkdown('pages', 'nosotros') || { content: 'Completar contenido desde el panel.' }
  return (
    <div className="py-10">
      <h1 className="text-3xl font-extrabold mb-6">Quiénes somos</h1>
      <div className="grid md:grid-cols-3 gap-10">
        <div className="md:col-span-2 prose" dangerouslySetInnerHTML={{ __html: marked.parse(page.content) }} />
        <aside className="card">
          <h4 className="font-semibold mb-2">Datos de contacto</h4>
          <p className="text-sm">{site.primaryEmail}</p>
          <p className="text-sm">{site.primaryPhone}</p>
          <p className="text-sm">{site.address}</p>
        </aside>
      </div>
    </div>
  )
}
