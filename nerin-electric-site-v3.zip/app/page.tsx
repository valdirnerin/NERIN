import Hero from '@/components/Hero'
import Link from 'next/link'
import { listItems, readMarkdown } from '@/lib/content'

export default function HomePage(){
  const latestPosts = listItems('blog').slice(0,3)
  const projects = listItems('projects').slice(0,3)
  return (
    <div className="space-y-16">
      <Hero />
      <section className="mt-12">
        <h2 className="text-2xl font-bold mb-4">Últimos artículos</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {latestPosts.map(slug => {
            const post = readMarkdown('blog', slug)
            return (
              <article key={slug} className="card">
                <h3 className="font-semibold text-lg"><Link href={`/blog/${slug}`}>{post?.data?.title || slug}</Link></h3>
                <div className="text-sm text-neutral-600">{post?.data?.excerpt}</div>
              </article>
            )
          })}
        </div>
        <div className="mt-4"><Link className="nav-link" href="/blog">Ver blog</Link></div>
      </section>
      <section>
        <h2 className="text-2xl font-bold mb-4">Trabajos destacados</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {projects.map(slug => {
            const pr = readMarkdown('projects', slug)
            return (
              <article key={slug} className="card">
                <h3 className="font-semibold text-lg"><Link href={`/proyectos/${slug}`}>{pr?.data?.title || slug}</Link></h3>
                <div className="text-sm text-neutral-600">{pr?.data?.excerpt}</div>
              </article>
            )
          })}
        </div>
        <div className="mt-4"><Link className="nav-link" href="/proyectos">Ver todos</Link></div>
      </section>
    </div>
  )
}
