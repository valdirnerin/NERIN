import fs from 'fs'
import path from 'path'
import { getStorageDir } from '@/lib/content'
export const metadata = { title: 'Paquetes corporativos | NERIN' }
export default function Precios(){
  const storage = getStorageDir()
  const p = path.join(storage, 'pricing.json')
  const pricing = fs.existsSync(p) ? JSON.parse(fs.readFileSync(p, 'utf8')) : { plans: [] }
  return (
    <div className="py-10">
      <h1 className="text-3xl font-extrabold mb-2">Paquetes corporativos de mantenimiento</h1>
      <p className="text-neutral-700 mb-6">Precios orientativos en ARS (mano de obra). Materiales y repuestos se cotizan aparte.</p>
      <div className="grid md:grid-cols-3 gap-6">
        {pricing.plans.map((pl:any) => (
          <div key={pl.slug} className="card">
            <div className="flex items-baseline justify-between">
              <h3 className="text-xl font-semibold">{pl.name}</h3>
              <div className="badge">${'{'}pl.price_ars.toLocaleString()}{'}'} / mes</div>
            </div>
            <p className="text-sm text-neutral-600 mt-1">{pl.description}</p>
            <ul className="mt-4 space-y-2 text-sm">
              {pl.features.map((f:string, i:number)=>(<li key={i}>• {f}</li>))}
            </ul>
            <div className="mt-4 text-sm text-neutral-600">Tiempo de respuesta: <b>{pl.sla}</b></div>
          </div>
        ))}
      </div>
      <div className="mt-8 text-sm text-neutral-600">¿Necesitás algo a medida? <a className="underline" href="/contacto">Contactanos</a>.</div>
    </div>
  )
}
