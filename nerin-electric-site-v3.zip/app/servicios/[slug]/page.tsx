import { readMarkdown } from '@/lib/content'
import { marked } from 'marked'
export default function Service({ params }: { params: { slug: string }}){
  const svc = readMarkdown('services', params.slug)
  if (!svc) return <div className="py-10">No encontrado.</div>
  return (
    <article className="py-10 prose">
      <h1 className="text-3xl font-extrabold">{svc.data.title}</h1>
      <div className="text-sm text-neutral-600 mb-6">{svc.data.excerpt}</div>
      <div dangerouslySetInnerHTML={{ __html: marked.parse(svc.content || '') }} />
    </article>
  )
}
