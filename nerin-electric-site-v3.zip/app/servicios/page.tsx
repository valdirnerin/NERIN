import { listItems, readMarkdown } from '@/lib/content'
import Link from 'next/link'
export const metadata = { title: 'Servicios | NERIN' }
export default function Services(){
  const slugs = listItems('services')
  return (
    <div className="py-10">
      <h1 className="text-3xl font-extrabold mb-6">Servicios para empresas</h1>
      <div className="grid md:grid-cols-3 gap-6">
        {slugs.map(slug => {
          const s = readMarkdown('services', slug)
          return (
            <article key={slug} className="card">
              <h3 className="text-xl font-semibold"><Link href={`/servicios/${slug}`}>{s?.data?.title || slug}</Link></h3>
              <p className="text-sm text-neutral-600">{s?.data?.excerpt}</p>
            </article>
          )
        })}
      </div>
    </div>
  )
}
