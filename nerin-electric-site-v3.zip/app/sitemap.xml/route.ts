import { listItems } from '@/lib/content'
export async function GET(){
  const now = new Date().toISOString()
  const urls = ['/', '/servicios', '/proyectos', '/blog', '/nosotros', '/contacto','/precios']
    .concat(listItems('blog').map(s=>`/blog/${s}`), listItems('services').map(s=>`/servicios/${s}`), listItems('projects').map(s=>`/proyectos/${s}`))
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.map(u => `<url><loc>${`https://example.com${u}`}</loc><lastmod>${now}</lastmod></url>`).join('\n')}
</urlset>`
  return new Response(xml, { headers: { 'Content-Type': 'application/xml' } })
}
