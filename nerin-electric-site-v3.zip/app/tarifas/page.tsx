import { readMarkdown } from '@/lib/content'
import { marked } from 'marked'

export const metadata = { title: 'Tarifas | NERIN' }

export default function Tarifas(){
  const page = readMarkdown('pages','tarifas') || { content: 'Cargá la página desde el panel (slug: tarifas).' }
  return (
    <article className="py-10 prose">
      <h1 className="text-3xl font-extrabold mb-4">Tarifas de mano de obra</h1>
      <div dangerouslySetInnerHTML={{ __html: marked.parse(page.content || '') }} />
    </article>
  )
}
