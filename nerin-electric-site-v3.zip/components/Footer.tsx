import Link from 'next/link'
import { readSite } from '@/lib/content'

export default function Footer(){
  const site = readSite()
  return (
    <footer className="mt-16 border-t border-black">
      <div className="container py-10 grid md:grid-cols-4 gap-8">
        <div>
          <img src={site.logo || '/logo-placeholder.svg'} alt="NERIN" className="h-10 w-auto" />
          <p className="text-sm text-neutral-600 mt-2">{site.tagline}</p>
        </div>
        <div>
          <h4 className="font-semibold mb-2">Empresa</h4>
          <ul className="space-y-1 text-sm">
            <li><Link href="/nosotros">Nosotros</Link></li>
            <li><Link href="/servicios">Servicios</Link></li>
            <li><Link href="/proyectos">Trabajos</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-2">Contacto</h4>
          <p className="text-sm">{site.primaryEmail}</p>
          <p className="text-sm">{site.primaryPhone}</p>
          <p className="text-sm">{site.address}</p>
        </div>
        <div>
          <h4 className="font-semibold mb-2">Redes</h4>
          <ul className="space-y-1 text-sm">
            <li><a target="_blank" href={site.social?.linkedin || '#'}>LinkedIn</a></li>
            <li><a target="_blank" href={site.social?.instagram || '#'}>Instagram</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-black text-center py-4 text-xs">© {new Date().getFullYear()} NERIN</div>
    </footer>
  )
}
