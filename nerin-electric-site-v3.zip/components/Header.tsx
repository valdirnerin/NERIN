'use client'
import Link from 'next/link'
import { useState } from 'react'

export default function Header(){
  const [open, setOpen] = useState(false)
  return (
    <header className="border-b border-black">
      <div className="container flex items-center justify-between py-4">
        <Link href="/" className="flex items-center gap-3">
          <img src="/logo-placeholder.svg" alt="NERIN" className="h-8 w-auto" />
          <span className="font-bold tracking-tight">NERIN Eléctrica</span>
        </Link>
        <nav className="hidden md:flex gap-6">
          <Link className="nav-link" href="/servicios">Servicios</Link>
          <Link className="nav-link" href="/proyectos">Trabajos</Link>
          <Link className="nav-link" href="/blog">Blog</Link>
          <Link className="nav-link" href="/precios">Paquetes</Link>
          <Link className="nav-link" href="/tarifas">Tarifas</Link>
          <Link className="nav-link" href="/calculadora">Calculadora</Link>
          <Link className="nav-link" href="/nosotros">Nosotros</Link>
          <Link className="nav-link" href="/contacto">Contacto</Link>
        </nav>
        <button className="md:hidden btn" onClick={()=>setOpen(x=>!x)}>Menú</button>
      </div>
      {open && (
        <div className="md:hidden border-t border-black">
          <div className="container py-3 flex flex-col gap-2">
            <Link href="/servicios">Servicios</Link>
            <Link href="/proyectos">Trabajos</Link>
            <Link href="/blog">Blog</Link>
            <Link href="/precios">Paquetes</Link>
            <Link href="/tarifas">Tarifas</Link>
            <Link href="/calculadora">Calculadora</Link>
            <Link href="/nosotros">Nosotros</Link>
            <Link href="/contacto">Contacto</Link>
          </div>
        </div>
      )}
    </header>
  )
}
