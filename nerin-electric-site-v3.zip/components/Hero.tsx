import { readSite } from '@/lib/content'
import Link from 'next/link'

export default function Hero(){
  const site = readSite()
  return (
    <section className="border-b border-black">
      <div className="container py-16 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <span className="badge">Empresas • Industria • Obra</span>
          <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mt-3">
            Ingeniería eléctrica para empresas que exigen calidad
          </h1>
          <p className="mt-4 text-lg text-neutral-700">
            Proyectos, instalaciones, mantenimiento y certificaciones. Cumplimos normativa AEA/IRAM y entregamos a tiempo.
          </p>
          <div className="mt-6 flex gap-3">
            <Link className="btn" href="/contacto">Solicitar presupuesto</Link>
            <Link className="btn" href="/proyectos">Ver trabajos</Link>
          </div>
        </div>
        <div className="card">
          <ul className="space-y-3 text-sm leading-relaxed">
            <li>✔ Tableros eléctricos de potencia y control</li>
            <li>✔ Instalaciones en oficinas, locales, depósitos y edificios</li>
            <li>✔ Mantenimiento preventivo y correctivo</li>
            <li>✔ Estudios de carga y certificaciones</li>
            <li>✔ Canalizaciones, CCTV, datos, audio y automatización</li>
          </ul>
        </div>
      </div>
    </section>
  )
}
