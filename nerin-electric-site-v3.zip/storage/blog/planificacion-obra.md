---
title: "Cómo planificar una instalación eléctrica corporativa sin sorpresas"
date: "2025-09-10"
excerpt: "Checklist ejecutivo para oficinas, locales y depósitos."
cover: ""
---
Planificar una obra eléctrica para empresas requiere **normativa**, **plazos** y **presupuesto** claros.
Este artículo te guía con un checklist breve que usamos en NERIN.
