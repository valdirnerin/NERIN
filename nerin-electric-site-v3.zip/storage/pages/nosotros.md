---
title: "Nosotros"
excerpt: ""
cover: ""
---
Somos **NERIN**, una empresa eléctrica orientada 100% a **clientes corporativos**. 
Combinamos ingeniería, cumplimiento normativo y obsesión por el detalle.
