---
title: "Tarifas"
excerpt: "Tarifario orientativo de mano de obra. Materiales aparte."
cover: ""
---
_Referencia CABA/GBA — valores orientativos **solo mano de obra**. Materiales y repuestos se cotizan aparte. Los precios finales pueden variar según relevamiento en sitio, riesgos, altura, accesos y plazos._

## Visitas, hora y mínimos
| Ítem | Unidad | ARS |
|---|---:|---:|
| Visita (inspección/diagnóstico/presupuesto) | por visita | 39.689 |
| Urgencia (Lu–Sa 20:00+, Dom/Feriado) (mín.) | por servicio | 95.151 |
| Hora de trabajo (mín.) | por hora | 39.689 |
| Service / Instalación (mín.) | por servicio | 79.239 |
| Boca completa (unidad básica) | por boca | 79.239 |

> **Boca completa**: canalización + amurado + cableado reglamentario + conexión de módulos/portalámparas de obra en cada centro luminoso. No incluye artefactos. Las cañerías se puntean; el cerrado/revoque lo hace el gremio correspondiente.

## Canalización y amurado
| Ítem | Unidad | ARS |
|---|---:|---:|
| En losa con caño metálico | por boca | 40.116 |
| En loseta con caño metálico | por boca | 42.120 |
| Amurado en mampostería (ladrillo común) | por boca | 45.589 |
| Amurado en mampostería (ladrillo hueco) | por boca | 44.505 |
| Amurado a la vista (metal, PVC, cablecanal 14×30) | por boca | 36.438 |
| Pase de viga/columna (1 boca por pase) | por boca | 42.311 |

> Extensión de cañería: **1 boca cada 5 m** adicionales.

## Cableado y conexiones
| Ítem | Unidad | ARS |
|---|---:|---:|
| Cableado en obra nueva – canalización propia | por boca | 19.496 |
| Cableado en obra nueva – canalización de tercero | por boca | 27.148 |
| Recableado **con** artefactos (sin vicios ocultos) | por boca | 40.710 |
| Recableado **sin** artefactos (sin vicios ocultos) | por boca | 27.148 |
| Punto/toma simple o portalámpara | por boca | 14.151 |
| Toma doble | por boca | 17.922 |
| Punto combinación | por boca | 15.231 |

## Tableros
| Ítem | Unidad | ARS |
|---|---:|---:|
| TP Monofásico (1 ID + 1 TM + PAT) | por ud. | 234.079 |
| TP Trifásico (1 ID + 1 TM + PAT) | por ud. | 316.987 |
| Solo puesta a tierra (PAT) | por ud. | 118.815 |
| Módulo adicional (ID, ITM u otro bipolar) | por ud. | 57.551 |
| ID tetrapolar | por ud. | 99.080 |
| ITM tetrapolar | por ud. | 99.080 |
| ITM tripolar | por ud. | 83.587 |
| Tablero seccional (hasta 8 polos) | por ud. | 166.365 |
| Tablero seccional (8–36 polos) | por ud. | 665.544 |
| Tablero seccional (36–54 polos) | por ud. | 998.270 |

## Iluminación (colocación de artefactos)
| Ítem | Unidad | ARS |
|---|---:|---:|
| Aplique simple | por ud. | 21.715 |
| Spot LED | por ud. | 21.715 |
| Colgante liviano 3 luces (1 efecto) | por ud. | 43.432 |
| Colgante liviano 5 luces (1 efecto) | por ud. | 57.535 |
| Adicional por efecto | por efecto | 14.151 |
| Colgante pesado (mín.) | por ud. | 75.985 |
| Tubo LED simple 7–36 W | por ud. | 43.432 |
| Tubo LED doble 7–36 W | por ud. | 53.464 |
| Tubo LED 45 W | por ud. | 54.312 |
| Tubo LED doble 45 W | por ud. | 67.396 |
| Ventilador de techo | por ud. | 79.239 |
| Ventilador de techo con luminaria (1 efecto) | por ud. | 99.080 |

## Acometidas y gabinetes
| Ítem | Unidad | ARS |
|---|---:|---:|
| Gabinete 1 medidor monofásico | por ud. | 166.365 |
| Gabinete 2 medidores monofásicos | por ud. | 237.755 |
| Gabinete 3 medidores monofásicos (incluye caja de toma 63 A) | por ud. | 554.660 |
| Gabinete 4 medidores monofásicos (incluye caja de toma 63 A) | por ud. | 633.890 |
| PAT de servicio (jabalina + caja inspección) | por ud. | 118.815 |
| Pilar completo (gabinete, TP, caño y PAT) | por ud. | 653.659 |
| Caño de acometida (amurado + conexión) | por ud. | 166.365 |
| Caja de toma (fusilera NH 00) | por ud. | 237.755 |
| Agregado de gabinete de medidor + TP | por ud. | 237.755 |

## Bandejas portacables (mano de obra)
| Ítem | Unidad | ARS |
|---|---:|---:|
| Hasta 150 mm ancho – H<3 m (metro lineal) | por m | 9.620 |
| Hasta 150 mm ancho – H>3 m (metro lineal) | por m | 12.846 |
| Accesorio (curva plana/unión T) H<3 m | por ud. | 6.427 |
| Accesorio (curva plana/unión T) H>3 m | por ud. | 12.033 |
| 200–300 mm ancho – H<3 m (metro lineal) | por m | 14.421 |
| 200–300 mm ancho – H>3 m (metro lineal) | por m | 19.259 |

## Certificados y documentación
| Ítem | Unidad | ARS |
|---|---:|---:|
| Proyecto eléctrico (mínimo 30 m²) | por m² (mín.) | 11.620 |
| Mínimo proyecto | — | 403.524 |
| Plano eléctrico (cálculo m² + bocas + tableros + acometida) | — | consultar |
| Certificado DCI – CAIE T1 Resid./Comercial Monofásico | por ud. | 310.350 |
| Certificado DCI – CAIE T1 Residencial Trifásico | por ud. | 465.525 |
| Certificado DCI – CAIE T1 Comercial Trifásico | por ud. | 465.525 |
| Protocolo de puesta a tierra SRT 900/15 (resid./com.) | por ud. | 496.560 |
| Protocolo de puesta a tierra SRT 900/15 (industrial) | por ud. | 496.560 |

## Potencia, grupos y urgencias
| Ítem | Unidad | ARS |
|---|---:|---:|
| Corrección de factor de potencia | por kVA | 102.950 |
| Grupo electrógeno monofásico (hasta 3,5 kVA) | por ud. | 198.133 |
| Emergencia/urgencia Lu–Sa 8–20 (atención inmediata) | por ud. | 79.239 |

## Jornales (8 h)
| Categoría | ARS |
|---|---:|
| Oficial especializado | 69.387 |
| Oficial electricista | 59.127 |
| Medio oficial | 54.541 |
| Ayudante | 50.045 |

---

**Condiciones sugeridas**  
- Materiales y repuestos: certificados IRAM/IEC.  
- Garantía: mano de obra y vicios aparentes (no cubre mal uso/sobrecargas).  
- Alcance: incluye tareas descriptas; obra civil por gremio correspondiente.  
- Vigencia del presupuesto: 15 días corridos (salvo indicación distinta).  
- Plazos: sujetos a disponibilidad, accesos y provisión de materiales.  
- Formas de pago: anticipo para materiales + saldo contra hitos/entrega.
