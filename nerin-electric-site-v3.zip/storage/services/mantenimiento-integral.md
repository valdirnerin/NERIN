---
title: "Mantenimiento eléctrico integral"
excerpt: "Contratos mensuales para oficinas y plantas: preventivo, correctivo y guardias."
cover: ""
---
Incluye termografías, mediciones, tableros, luces de emergencia, puesta a tierra y reportes ejecutivos.
